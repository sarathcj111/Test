﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using TestMVC.Models;
using TestMVC.Repository.Interface;

namespace TestMVC.Repository
{
    public class BookRepository: IBookRepository
    {
        private readonly IConfiguration _config;
        public BookRepository(IConfiguration config)
        {
            _config = config;
        }
        private List<BookModel> bookList = new List<BookModel>();

        private List<BookModel> GenerateBookList()
        {
            for(var i = 0; i <= 2; i++)
            {
                BookModel book = new BookModel();
                book.Id = _config.GetValue<int>($"Book{i+1}:Id");
                book.Title = _config.GetValue<string>($"Book{i+1}:Title");
                book.Genre = _config.GetValue<string>($"Book{i+1}:Genre");
                book.Price = _config.GetValue<decimal>($"Book{i+1}:Price");
                bookList.Add(book);
            }
            return bookList;
        }
        public List<BookModel> AddNewBook(BookModel book)
        {
            var books = GenerateBookList();
            book.Id = books.Count + 1;
            books.Add(book);
            AddtoJson(book); // ignore this line.
            return books;
        }
        public List<BookModel> GetAllBooks()
        {
            GenerateBookList();
            return bookList;
        }
        public List<BookModel> EditBook(int bookId)
        {
            var books = GenerateBookList();
            var book = books.Find(x => x.Id == bookId);
            book.Title = "edited " + book.Title;
            return books;
        }
        public bool DeleteBook(int bookId,out List<BookModel> books)
        {
            books = GenerateBookList();
            books.Remove(books.Find(x => x.Id == bookId));
            var book = books.Find(x => x.Id == bookId);
            if (book == null)
            {
                RemoveFromJson(bookId); // ignore this line.
                return true;
            }
            else
                return false;
        }


        // Do not pay attention to this part..
        private void AddtoJson(BookModel book)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            dynamic newBook = JsonConvert.DeserializeObject<ExpandoObject>(JsonConvert.SerializeObject(book), jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Add($"Book{book.Id}", newBook);

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            File.WriteAllText(appSettingsPath, newJson);
        }

        private void RemoveFromJson(int bookId)
        {
            var appSettingsPath = Path.Combine(System.IO.Directory.GetCurrentDirectory(), "appsettings.json");
            var json = File.ReadAllText(appSettingsPath);

            var jsonSettings = new JsonSerializerSettings();
            jsonSettings.Converters.Add(new ExpandoObjectConverter());
            jsonSettings.Converters.Add(new StringEnumConverter());

            dynamic config = JsonConvert.DeserializeObject<ExpandoObject>(json, jsonSettings);

            var expando = config as IDictionary<string, object>;
            expando.Remove($"Book{bookId}");

            var newJson = JsonConvert.SerializeObject(config, Formatting.Indented, jsonSettings);

            File.WriteAllText(appSettingsPath, newJson);
        }
    }
}
